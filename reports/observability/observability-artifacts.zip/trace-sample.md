﻿# Muestras de trazas

```
  traceId: '91d883b521c9d419493087f2aedb4b8c',
  parentSpanContext: undefined,
  traceState: undefined,
  name: 'GET /api/health',
  id: 'f7bf7efabcfd54ea',
---
  traceId: '91d883b521c9d419493087f2aedb4b8c'
} GET /api/health 200
{
  resource: {
    attributes: { 'service.name': 'puranatura-api', 'service.version': '0.0.0' }
---
  traceId: '6429bf3c88b7f97f1acb81ec6c01e7fc',
  parentSpanContext: undefined,
  traceState: undefined,
  name: 'GET /',
  id: 'a96c1a9d533760a9',
---
```
