﻿# Muestras de trazas

```
  traceId: '61f027a37afa1bd71a74b60281cb31c2',
  parentSpanContext: undefined,
  traceState: undefined,
  name: 'GET /api/health',
  id: '40bff408f0bd6ca1',
---
  traceId: '61f027a37afa1bd71a74b60281cb31c2'
} GET /api/health 200
{
  resource: {
    attributes: { 'service.name': 'puranatura-api', 'service.version': '0.0.0' }
---
  traceId: 'e6b08072a1594643a81097dfcb654584',
  parentSpanContext: undefined,
  traceState: undefined,
  name: 'GET /',
  id: 'b9da8844666a72bc',
---
```
